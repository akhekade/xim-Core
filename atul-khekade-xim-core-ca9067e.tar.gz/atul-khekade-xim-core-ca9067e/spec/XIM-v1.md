# XIM v1 — XDC Interledger Message

Status: draft
Version: 1
Hash function: Keccak-256 (the function Solidity calls `keccak256`)

XIM is the message layer of an XDC interledger. A message names a source observation, a destination, an action, and the proof and policy commitments that travel with it. The protocol commits to three things:

- a **message id**, which identifies the message for replay protection
- a **message hash**, which commits to the full canonical body
- a **sparse Merkle root** over the current lifecycle state of every message

XIM holds commitments, proofs, and message state. It does not store foreign-chain ledgers, route liquidity, or move assets by itself. Adapters, verifiers, and settlement contracts consume this format.

The normative encoding is **XCE-1**, defined in this document. `proto/xim/v1/message.proto` is the interchange schema. Protobuf wire bytes are a carrier. Implementations that hash messages use XCE-1.

The reference implementation in this repository, together with `spec/test-vectors.json`, is the known-answer suite. An implementation is conformant when it reproduces that file.

## 1. Conventions

The key words MUST, MUST NOT, and MAY are requirements on implementations.

Integers are unsigned and big-endian. `uint8`, `uint32`, `uint64`, and `uint256` occupy 1, 4, 8, and 32 bytes.

A **string** is `uint32` byte-length followed by UTF-8 bytes. The length MUST be at most 1024. The length counts bytes, not Unicode scalar values.

A **bytes32** value is exactly 32 bytes. In JSON it is `0x` plus 64 hexadecimal characters. Encoders MUST write lowercase hex. Parsers MUST accept `0x` and `0X`.

Domain tags are the following 8-byte ASCII strings. The trailing bytes are the raw values shown, including NULs.

| Name | ASCII | Hex |
| --- | --- | --- |
| `DOMAIN_ID` | `XIMID` `0x01 0x00 0x00` | `58494d4944010000` |
| `DOMAIN_MSG` | `XIMMSG` `0x01 0x00` | `58494d4d53470100` |
| `DOMAIN_STATE` | `XIMSTA` `0x01 0x00` | `58494d5354410100` |
| `DOMAIN_LEAF` | `XIMLEAF` `0x01` | `58494d4c45414601` |
| `DOMAIN_NODE` | `XIMNODE` `0x01` | `58494d4e4f444501` |
| `DOMAIN_EMPTY` | `XIMEMPTY` | `58494d454d505459` |
| `DOMAIN_EVENT` | `XIMEVT` `0x01 0x00` | `58494d4556540100` |

Keccak-256 of the empty input is `c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470`. Implementations MUST match that vector before trusting any other hash.

## 2. Network identifiers

A network id matches:

```text
^[a-z0-9][a-z0-9-]{0,31}:[A-Za-z0-9._:-]{1,128}$
```

The namespace is lowercase. These identifiers are well known:

| Network | Identifier |
| --- | --- |
| XDC mainnet | `eip155:50` |
| XDC Apothem | `eip155:51` |
| Ethereum mainnet | `eip155:1` |
| Ethereum Sepolia | `eip155:11155111` |
| XIM log | `xim:1` |

`xim:1` names an observation made by the interledger log itself, such as a commitment or a verification, when that observation is not a transaction on a connected chain. Other networks use the same grammar. A Canton domain, for example, can be written `canton:global`.

## 3. Parties

A party is either an EVM address or a free-form identifier.

An EVM address matches `0x` or `xdc`, in either case, plus 40 hexadecimal characters. Encoders MUST normalize it to lowercase `0x` plus 40 lowercase hex characters before hashing. `xdc2222…` and `0x2222…` are the same party.

Any other party MUST be 1 to 256 characters of printable ASCII (`0x20` through `0x7E`) with no leading or trailing space. Those identifiers are case-sensitive. A Canton party id or a bank identifier stays as written.

## 4. Message

Version MUST be 1.

### 4.1 Fields

| Field | Type | Meaning |
| --- | --- | --- |
| `version` | uint32 | Always 1 |
| `source.networkId` | string | Chain where the source transaction was observed |
| `source.blockHeight` | uint64 | Block that contains the source transaction |
| `source.txHash` | bytes32 | Source transaction hash |
| `source.sender` | string | Account or institution that initiated the message |
| `destination.networkId` | string | Chain or rail that should receive the action |
| `destination.receiver` | string | Account or institution that receives the action |
| `action.type` | uint8 | Action code from the table below |
| `action.assetId` | string | Asset identifier, 1 to 128 characters of `[A-Za-z0-9:._-]` |
| `action.amount` | uint256 | Integer amount in the asset's smallest unit |
| `action.payloadHash` | bytes32 | Hash of any extra payload. 32 zero bytes means no payload |
| `security.nonce` | uint64 | Replay discriminator |
| `security.timestamp` | uint64 | Unix seconds when the message was created |
| `security.expiry` | uint64 | Unix seconds when the intent expires |
| `security.finalityRequirement` | uint8 | Minimum source finality the sender requires |
| `security.proofType` | uint8 | Kind of proof attached to the source observation |
| `security.proofHash` | bytes32 | Hash of that proof. 32 zero bytes means none |
| `policy.complianceHash` | bytes32 | Commitment to a compliance bundle. 32 zero bytes means none |
| `policy.jurisdiction` | string | Empty, or an uppercase token such as `US` or `US-NY` |
| `policy.privacy` | uint8 | How much of the underlying business object may be disclosed |

`expiry` MUST be greater than `timestamp`. The message is valid over the half-open interval `[timestamp, expiry)`.

`amount` is an integer. `10000000` of `UAID:USDC:CIRCLE:USD` is 10 USDC when that asset uses 6 decimal places. XIM does not interpret decimals.

Asset identifiers SHOULD use:

```text
UAID:<symbol>:<issuer>:<currency>
```

The identifier is opaque to the hasher aside from the character set above. `UAID:USDC:CIRCLE:USD` names the asset, not a token contract on one chain.

### 4.2 Codes

Action:

| Name | Code |
| --- | --- |
| `TRANSFER` | 1 |
| `EXECUTE` | 2 |
| `SETTLE` | 3 |
| `ACK` | 4 |
| `REFUND` | 5 |
| `DATA` | 6 |

Finality, in increasing order:

| Name | Code |
| --- | --- |
| `INSTANT` | 1 |
| `CONFIRMED` | 2 |
| `INSTITUTIONAL` | 3 |
| `FINAL` | 4 |

Proof type:

| Name | Code |
| --- | --- |
| `NONE` | 0 |
| `LIGHT_CLIENT` | 1 |
| `ZK_PROOF` | 2 |
| `THRESHOLD_ATTESTATION` | 3 |
| `NATIVE_PROOF` | 4 |
| `TEE_ATTESTATION` | 5 |
| `HYBRID` | 6 |

Privacy:

| Name | Code |
| --- | --- |
| `PUBLIC` | 1 |
| `HASH_ONLY` | 2 |
| `PRIVATE` | 3 |

JSON objects MUST contain only the fields named in this spec. Integers in the canonical JSON form are decimal strings. Parsers MAY also accept safe JSON numbers.

### 4.3 Message hash

`canonicalMessageBytes` is the concatenation, in this order:

1. `DOMAIN_MSG`
2. `version` as uint32
3. `source.networkId` as string
4. `source.blockHeight` as uint64
5. `source.txHash`
6. `source.sender` as string
7. `destination.networkId` as string
8. `destination.receiver` as string
9. action type as uint8
10. `action.assetId` as string
11. `action.amount` as uint256
12. `action.payloadHash`
13. `security.nonce` as uint64
14. `security.timestamp` as uint64
15. `security.expiry` as uint64
16. finality requirement as uint8
17. proof type as uint8
18. `security.proofHash`
19. `policy.complianceHash`
20. `policy.jurisdiction` as string
21. privacy as uint8

```text
messageHash = keccak256(canonicalMessageBytes)
```

A decoder MUST reject a truncated preimage, a trailing suffix, an unknown code, or a string that is not valid UTF-8.

### 4.4 Message id

The message id is a replay key. Its preimage is:

1. `DOMAIN_ID`
2. `version` as uint32
3. `source.networkId` as string
4. `source.txHash`
5. `destination.networkId` as string
6. `source.sender` as string
7. `destination.receiver` as string
8. `security.nonce` as uint64
9. `action.payloadHash`

```text
messageId = keccak256(messageIdPreimage)
```

The id commits to version, both networks, the source transaction, both parties, the nonce, and the payload hash. The amount, expiry, fees, and policy travel in `messageHash`. A sender that changes the amount MUST use a new nonce. Engines MUST reject a second message whose id is already present, and the `CREATED` event MUST store `messageHash` in `proofHash` so the full body is anchored in the log.

## 5. Lifecycle

Every accepted message starts in `CREATED`. An engine MUST NOT skip a state.

| From | To |
| --- | --- |
| `CREATED` | `SOURCE_FINAL`, `FAILED`, `EXPIRED` |
| `SOURCE_FINAL` | `COMMITTED`, `FAILED`, `EXPIRED` |
| `COMMITTED` | `VERIFIED`, `FAILED`, `EXPIRED` |
| `VERIFIED` | `EXECUTING`, `FAILED`, `EXPIRED` |
| `EXECUTING` | `SETTLED`, `FAILED` |
| `SETTLED` | `ACKNOWLEDGED`, `REFUNDED` |
| `FAILED` | `REFUNDED` |
| `EXPIRED` | `REFUNDED` |
| `ACKNOWLEDGED` | none |
| `REFUNDED` | none |

Codes match the names: `CREATED` is 1 through `REFUNDED` is 10.

| Name | Code |
| --- | --- |
| `CREATED` | 1 |
| `SOURCE_FINAL` | 2 |
| `COMMITTED` | 3 |
| `VERIFIED` | 4 |
| `EXECUTING` | 5 |
| `SETTLED` | 6 |
| `ACKNOWLEDGED` | 7 |
| `FAILED` | 8 |
| `EXPIRED` | 9 |
| `REFUNDED` | 10 |

`CREATED` is produced by accepting a message. It is not a later transition.

### 5.1 State value

The value stored in the Merkle tree is:

```text
stateHash = keccak256(canonicalStateBytes)
```

`canonicalStateBytes` is:

1. `DOMAIN_STATE`
2. status as uint8
3. `sourceFinality` as uint8 (`0` until a finality observation, otherwise a finality code)
4. `verificationHash` as bytes32
5. `executionHash` as bytes32
6. `destinationTxHash` as bytes32

Unset hashes are 32 zero bytes.

### 5.2 Transition rules

A transition carries `status`, `networkId`, `blockHeight`, `timestamp`, and optional `sourceFinality`, `verificationHash`, `executionHash`, `destinationTxHash`, and `proofHash`.

- `timestamp` MUST be greater than or equal to the timestamp of the previous event for that message.
- When `networkId` is the source network, `blockHeight` MUST be greater than or equal to `source.blockHeight`.
- `SOURCE_FINAL` MUST be observed on the source network and MUST set `sourceFinality` to `CONFIRMED`, `INSTITUTIONAL`, or `FINAL`.
- `ACKNOWLEDGED` MUST be observed on the source network.
- `EXECUTING` and `SETTLED` MUST be observed on the destination network.
- `VERIFIED` MUST set a non-zero `verificationHash`.
- `SETTLED` MUST set a non-zero `destinationTxHash`.
- `COMMITTED` and `VERIFIED` MAY use `xim:1`.
- While the message is in `CREATED`, `SOURCE_FINAL`, `COMMITTED`, or `VERIFIED`, a transition whose timestamp is at or after `expiry` MUST be `EXPIRED` or `FAILED`.
- `EXPIRED` MUST use a timestamp at or after `expiry`.
- Once execution has started, expiry does not pull the message backward. `EXECUTING` still proceeds to `SETTLED` or `FAILED`.
- `sourceFinality` MAY rise on a later transition. It MUST NOT fall.
- A non-zero hash field MAY be set once. Repeating the same bytes is a no-op. Writing a different non-zero value MUST be rejected.
- The settlement transaction stays in `destinationTxHash`. A refund transaction after settlement MUST be carried in the event `proofHash`.

If a `COMMITTED` transition omits `proofHash`, the engine uses the sparse Merkle root after the transition. Every other omitted `proofHash` is 32 zero bytes.

### 5.3 Illustrative path

`examples/usdc-eth-to-xdc.json` is a transfer of 10 USDC units from Ethereum to XDC. One conforming lifecycle is:

```text
CREATED         on eip155:1, proofHash = messageHash
SOURCE_FINAL    on eip155:1, after the source finality depth
COMMITTED       on xim:1, proofHash = the new Merkle root
VERIFIED        on xim:1, with the verifier's hash
EXECUTING       on eip155:50
SETTLED         on eip155:50, with the destination transaction
ACKNOWLEDGED    on eip155:1
```

Whether the source action was a burn, a lock, or an API instruction is the verifier's concern. XIM records the message and the proofs.

## 6. Event log

Each accepted transition appends one event. The log is totally ordered inside one engine. The preimage is:

1. `DOMAIN_EVENT`
2. `previousEventHash` (32 zero bytes for the first event)
3. `messageId`
4. status as uint8
5. `networkId` as string
6. `blockHeight` as uint64
7. `timestamp` as uint64
8. `previousStateHash`
9. `newStateHash`
10. `proofHash`

```text
eventHash = keccak256(canonicalEventBytes)
```

For a message's first event, `status` is `CREATED`, `previousStateHash` is 32 zero bytes, and `proofHash` is `messageHash`. Each later event for that message MUST set `previousStateHash` to the previous event's `newStateHash`, and the status MUST be a legal successor.

`verifyEventChain` checks those links. It does not recompute `newStateHash` from a message body. Anchoring the Merkle root is what binds the log to the state values.

A replay log is the caller inputs, not the derived hashes:

```json
{
  "xim": "1",
  "entries": [
    { "kind": "create", "message": {} },
    { "kind": "transition", "messageId": "0x…", "transition": {} }
  ]
}
```

Replaying the entries MUST reproduce the event hashes and the Merkle root.

## 7. Sparse Merkle tree

The tree has depth 256. The key is `messageId`. Bit 0 is the most significant bit of the first key byte and selects the branch under the root. Bit 255 is the least significant bit of the last key byte and selects the leaf.

The value stored at a present key is `stateHash`.

```text
empty[256] = keccak256(DOMAIN_EMPTY)
empty[d]   = keccak256(DOMAIN_NODE || empty[d + 1] || empty[d + 1])   for d from 255 down to 0
leaf       = keccak256(DOMAIN_LEAF || key || valueHash)
node       = keccak256(DOMAIN_NODE || left || right)
```

`||` is raw concatenation. A bit value of 0 means the running hash is the left child. A bit value of 1 means it is the right child.

An absent position uses `empty[256]` as its starting hash. The empty root is `empty[0]`. Inserting the same set of key-value pairs MUST produce the same root regardless of insertion order. Removing every key MUST return the tree to `empty[0]`.

### 7.1 Compact proofs

A proof contains:

| Field | Meaning |
| --- | --- |
| `key` | 32-byte message id |
| `valueHash` | 32-byte state hash, or null when proving absence |
| `bitmap` | 32 bytes |
| `siblings` | the non-default sibling hashes, from the leaf toward the root |

Bitmap index `i` is bit `i mod 8` of byte `floor(i / 8)`, and bit 0 of a byte is its least significant bit. Index 0 is the sibling at depth 256. A set bit means the next sibling in the list replaces the default. A clear bit means the sibling is `empty[depth]`.

Verification starts from `leaf` when `valueHash` is present and from `empty[256]` when it is null, then folds each sibling up to depth 0. The result MUST equal the anchored root. The number of set bits MUST equal `siblings.length`.

## 8. What this version leaves to the next layer

Verifiers still have to check source finality, light-client headers, threshold signatures, and bank attestations. XIM names the proof type and stores the proof hash. Routing, fees, ISO 20022 translation, liquidity, and the on-chain anchor contract are separate layers. They should take a message id, a message hash, a compact proof, and a root as their inputs.

## 9. Test vectors

`npm run vectors` writes `spec/test-vectors.json` from `examples/usdc-eth-to-xdc.json` and the reference lifecycle in `src/demo.ts`. The file includes the domain tags, the empty-string Keccak vector, the empty Merkle root, both preimages for the sample message, and the replay log.
