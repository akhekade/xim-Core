# Changelog

## 0.1.0

Initial draft of XIM v1.

- Canonical message encoding (XCE-1) and Keccak message ids
- Lifecycle engine with an append-only event log and replay
- Sparse Merkle commitments and compact inclusion and absence proofs
- Sample Ethereum-to-XDC USDC transfer and known-answer vectors
