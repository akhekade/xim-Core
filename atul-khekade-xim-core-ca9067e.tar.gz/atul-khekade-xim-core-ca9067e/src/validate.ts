import { MAX_U256, MAX_U64, copyBytes, fromHex, toHex } from "./bytes.js";
import {
  ACTION_TYPE,
  FINALITY,
  MESSAGE_STATUS,
  PRIVACY,
  PROOF_TYPE,
  parseEnum,
} from "./enums.js";
import { XimError } from "./errors.js";
import type { MessageJson, TransitionInput, TransitionJson, XimMessage } from "./types.js";

const NETWORK_ID = /^[a-z0-9][a-z0-9-]{0,31}:[A-Za-z0-9._:-]{1,128}$/;
const ASSET_ID = /^[A-Za-z0-9:._-]{1,128}$/;
const JURISDICTION = /^[A-Z][A-Z0-9-]{0,15}$/;
const EVM_PARTY = /^(?:0x|0X|xdc|XDC)([0-9a-fA-F]{40})$/;

export function assertNetworkId(value: string, field: string): string {
  if (typeof value !== "string" || !NETWORK_ID.test(value)) {
    throw new XimError(
      "INVALID_MESSAGE",
      `${field} must be a lowercase namespace, a colon, and a reference`,
    );
  }
  return value;
}

/** EVM parties accept `0x` and XDC `xdc` spellings and become lowercase `0x` addresses. */
export function normalizeParty(party: string, field: string): string {
  if (typeof party !== "string") {
    throw new XimError("INVALID_MESSAGE", `${field} must be a string`);
  }
  const evm = EVM_PARTY.exec(party);
  if (evm?.[1]) return `0x${evm[1].toLowerCase()}`;
  if (party.length < 1 || party.length > 256 || party !== party.trim() || !/^[\x20-\x7E]+$/.test(party)) {
    throw new XimError(
      "INVALID_MESSAGE",
      `${field} must be an EVM address or 1 to 256 printable ASCII characters`,
    );
  }
  return party;
}

export function parseUint(value: unknown, max: bigint, field: string): bigint {
  let parsed: bigint;
  if (typeof value === "bigint") parsed = value;
  else if (typeof value === "number") {
    if (!Number.isSafeInteger(value)) {
      throw new XimError("INVALID_MESSAGE", `${field} must be an integer`);
    }
    parsed = BigInt(value);
  } else if (typeof value === "string" && /^[0-9]+$/.test(value)) parsed = BigInt(value);
  else throw new XimError("INVALID_MESSAGE", `${field} must be an unsigned integer`);

  if (parsed < 0n || parsed > max) {
    throw new XimError("INVALID_MESSAGE", `${field} is out of range`);
  }
  return parsed;
}

export function parseHash(value: unknown, field: string): Uint8Array {
  if (typeof value !== "string") {
    throw new XimError("INVALID_MESSAGE", `${field} must be 32 bytes of hex`);
  }
  try {
    return fromHex(value, 32);
  } catch (error) {
    if (error instanceof XimError) {
      throw new XimError("INVALID_MESSAGE", `${field} must be 32 bytes of hex`);
    }
    throw error;
  }
}

function asRecord(value: unknown, field: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) {
    throw new XimError("INVALID_MESSAGE", `${field} must be an object`);
  }
  return value as Record<string, unknown>;
}

function onlyKeys(value: Record<string, unknown>, keys: readonly string[], field: string): void {
  for (const key of Object.keys(value)) {
    if (!keys.includes(key)) {
      throw new XimError("INVALID_MESSAGE", `${field} has unknown field ${key}`);
    }
  }
}

function required(value: Record<string, unknown>, key: string, field: string): unknown {
  if (!Object.prototype.hasOwnProperty.call(value, key)) {
    throw new XimError("INVALID_MESSAGE", `${field} is missing ${key}`);
  }
  return value[key];
}

function assertU64(value: bigint, field: string): bigint {
  return parseUint(value, MAX_U64, field);
}

/** Validate and copy a message, normalizing EVM party spellings. */
export function normalizeMessage(message: XimMessage): XimMessage {
  if (message.version !== 1) throw new XimError("INVALID_MESSAGE", "version must be 1");
  const sourceNetwork = assertNetworkId(message.source.networkId, "source.networkId");
  const destinationNetwork = assertNetworkId(message.destination.networkId, "destination.networkId");
  const sender = normalizeParty(message.source.sender, "source.sender");
  const receiver = normalizeParty(message.destination.receiver, "destination.receiver");
  const blockHeight = assertU64(message.source.blockHeight, "source.blockHeight");
  const txHash = parseHash(toHex(message.source.txHash), "source.txHash");
  const type = parseEnum(ACTION_TYPE, message.action.type, "action.type");
  if (typeof message.action.assetId !== "string" || !ASSET_ID.test(message.action.assetId)) {
    throw new XimError("INVALID_MESSAGE", "action.assetId must be 1 to 128 ASCII identifier characters");
  }
  const amount = parseUint(message.action.amount, MAX_U256, "action.amount");
  const payloadHash = parseHash(toHex(message.action.payloadHash), "action.payloadHash");
  const nonce = assertU64(message.security.nonce, "security.nonce");
  const timestamp = assertU64(message.security.timestamp, "security.timestamp");
  const expiry = assertU64(message.security.expiry, "security.expiry");
  if (expiry <= timestamp) {
    throw new XimError("INVALID_MESSAGE", "security.expiry must be greater than security.timestamp");
  }
  const finalityRequirement = parseEnum(
    FINALITY,
    message.security.finalityRequirement,
    "security.finalityRequirement",
  );
  const proofType = parseEnum(PROOF_TYPE, message.security.proofType, "security.proofType");
  const proofHash = parseHash(toHex(message.security.proofHash), "security.proofHash");
  const complianceHash = parseHash(toHex(message.policy.complianceHash), "policy.complianceHash");
  if (typeof message.policy.jurisdiction !== "string") {
    throw new XimError("INVALID_MESSAGE", "policy.jurisdiction must be a string");
  }
  if (message.policy.jurisdiction !== "" && !JURISDICTION.test(message.policy.jurisdiction)) {
    throw new XimError("INVALID_MESSAGE", "policy.jurisdiction must be empty or an uppercase token");
  }
  const privacy = parseEnum(PRIVACY, message.policy.privacy, "policy.privacy");

  return {
    version: 1,
    source: { networkId: sourceNetwork, blockHeight, txHash, sender },
    destination: { networkId: destinationNetwork, receiver },
    action: { type, assetId: message.action.assetId, amount, payloadHash },
    security: { nonce, timestamp, expiry, finalityRequirement, proofType, proofHash },
    policy: { complianceHash, jurisdiction: message.policy.jurisdiction, privacy },
  };
}

export function isXimMessage(value: XimMessage | MessageJson): value is XimMessage {
  return typeof value.action?.amount === "bigint";
}

export function parseMessage(input: unknown): XimMessage {
  const root = asRecord(input, "message");
  onlyKeys(root, ["version", "source", "destination", "action", "security", "policy"], "message");
  if (required(root, "version", "message") !== 1) {
    throw new XimError("INVALID_MESSAGE", "version must be 1");
  }
  const source = asRecord(required(root, "source", "message"), "source");
  onlyKeys(source, ["networkId", "blockHeight", "txHash", "sender"], "source");
  const destination = asRecord(required(root, "destination", "message"), "destination");
  onlyKeys(destination, ["networkId", "receiver"], "destination");
  const action = asRecord(required(root, "action", "message"), "action");
  onlyKeys(action, ["type", "assetId", "amount", "payloadHash"], "action");
  const security = asRecord(required(root, "security", "message"), "security");
  onlyKeys(
    security,
    ["nonce", "timestamp", "expiry", "finalityRequirement", "proofType", "proofHash"],
    "security",
  );
  const policy = asRecord(required(root, "policy", "message"), "policy");
  onlyKeys(policy, ["complianceHash", "jurisdiction", "privacy"], "policy");

  const draft: XimMessage = {
    version: 1,
    source: {
      networkId: String(required(source, "networkId", "source")),
      blockHeight: parseUint(required(source, "blockHeight", "source"), MAX_U64, "source.blockHeight"),
      txHash: parseHash(required(source, "txHash", "source"), "source.txHash"),
      sender: String(required(source, "sender", "source")),
    },
    destination: {
      networkId: String(required(destination, "networkId", "destination")),
      receiver: String(required(destination, "receiver", "destination")),
    },
    action: {
      type: parseEnum(ACTION_TYPE, required(action, "type", "action"), "action.type"),
      assetId: String(required(action, "assetId", "action")),
      amount: parseUint(required(action, "amount", "action"), MAX_U256, "action.amount"),
      payloadHash: parseHash(required(action, "payloadHash", "action"), "action.payloadHash"),
    },
    security: {
      nonce: parseUint(required(security, "nonce", "security"), MAX_U64, "security.nonce"),
      timestamp: parseUint(required(security, "timestamp", "security"), MAX_U64, "security.timestamp"),
      expiry: parseUint(required(security, "expiry", "security"), MAX_U64, "security.expiry"),
      finalityRequirement: parseEnum(
        FINALITY,
        required(security, "finalityRequirement", "security"),
        "security.finalityRequirement",
      ),
      proofType: parseEnum(PROOF_TYPE, required(security, "proofType", "security"), "security.proofType"),
      proofHash: parseHash(required(security, "proofHash", "security"), "security.proofHash"),
    },
    policy: {
      complianceHash: parseHash(required(policy, "complianceHash", "policy"), "policy.complianceHash"),
      jurisdiction: String(required(policy, "jurisdiction", "policy")),
      privacy: parseEnum(PRIVACY, required(policy, "privacy", "policy"), "policy.privacy"),
    },
  };
  return normalizeMessage(draft);
}

export function messageToJson(message: XimMessage): MessageJson {
  const normalized = normalizeMessage(message);
  return {
    version: 1,
    source: {
      networkId: normalized.source.networkId,
      blockHeight: normalized.source.blockHeight.toString(),
      txHash: toHex(normalized.source.txHash),
      sender: normalized.source.sender,
    },
    destination: {
      networkId: normalized.destination.networkId,
      receiver: normalized.destination.receiver,
    },
    action: {
      type: normalized.action.type,
      assetId: normalized.action.assetId,
      amount: normalized.action.amount.toString(),
      payloadHash: toHex(normalized.action.payloadHash),
    },
    security: {
      nonce: normalized.security.nonce.toString(),
      timestamp: normalized.security.timestamp.toString(),
      expiry: normalized.security.expiry.toString(),
      finalityRequirement: normalized.security.finalityRequirement,
      proofType: normalized.security.proofType,
      proofHash: toHex(normalized.security.proofHash),
    },
    policy: {
      complianceHash: toHex(normalized.policy.complianceHash),
      jurisdiction: normalized.policy.jurisdiction,
      privacy: normalized.policy.privacy,
    },
  };
}

export function parseTransition(input: unknown): TransitionInput {
  const root = asRecord(input, "transition");
  onlyKeys(
    root,
    [
      "status",
      "networkId",
      "blockHeight",
      "timestamp",
      "sourceFinality",
      "verificationHash",
      "executionHash",
      "destinationTxHash",
      "proofHash",
    ],
    "transition",
  );
  const status = parseEnum(MESSAGE_STATUS, required(root, "status", "transition"), "status");
  if (status === "CREATED") {
    throw new XimError("ILLEGAL_TRANSITION", "CREATED is produced by create, not by transition");
  }
  const transition: TransitionInput = {
    status,
    networkId: assertNetworkId(String(required(root, "networkId", "transition")), "networkId"),
    blockHeight: parseUint(required(root, "blockHeight", "transition"), MAX_U64, "blockHeight"),
    timestamp: parseUint(required(root, "timestamp", "transition"), MAX_U64, "timestamp"),
  };
  if (root.sourceFinality !== undefined) {
    transition.sourceFinality = parseEnum(FINALITY, root.sourceFinality, "sourceFinality");
  }
  if (root.verificationHash !== undefined) {
    transition.verificationHash = parseHash(root.verificationHash, "verificationHash");
  }
  if (root.executionHash !== undefined) transition.executionHash = parseHash(root.executionHash, "executionHash");
  if (root.destinationTxHash !== undefined) {
    transition.destinationTxHash = parseHash(root.destinationTxHash, "destinationTxHash");
  }
  if (root.proofHash !== undefined) transition.proofHash = parseHash(root.proofHash, "proofHash");
  return transition;
}

export function transitionToJson(input: TransitionInput): TransitionJson {
  const json: TransitionJson = {
    status: input.status,
    networkId: assertNetworkId(input.networkId, "networkId"),
    blockHeight: assertU64(input.blockHeight, "blockHeight").toString(),
    timestamp: assertU64(input.timestamp, "timestamp").toString(),
  };
  if (input.sourceFinality) json.sourceFinality = parseEnum(FINALITY, input.sourceFinality, "sourceFinality");
  if (input.verificationHash) json.verificationHash = toHex(input.verificationHash);
  if (input.executionHash) json.executionHash = toHex(input.executionHash);
  if (input.destinationTxHash) json.destinationTxHash = toHex(input.destinationTxHash);
  if (input.proofHash) json.proofHash = toHex(input.proofHash);
  return json;
}

export function cloneMessage(message: XimMessage): XimMessage {
  const normalized = normalizeMessage(message);
  return {
    ...normalized,
    source: { ...normalized.source, txHash: copyBytes(normalized.source.txHash) },
    destination: { ...normalized.destination },
    action: { ...normalized.action, payloadHash: copyBytes(normalized.action.payloadHash) },
    security: { ...normalized.security, proofHash: copyBytes(normalized.security.proofHash) },
    policy: { ...normalized.policy, complianceHash: copyBytes(normalized.policy.complianceHash) },
  };
}
