import { bytesEqual, concat, copyBytes, fromHex, getBit, toHex } from "./bytes.js";
import { DOMAIN_EMPTY, DOMAIN_LEAF, DOMAIN_NODE } from "./domain.js";
import { XimError } from "./errors.js";
import { keccak256 } from "./hash.js";

const DEPTH = 256;

function buildEmpty(): Uint8Array[] {
  const empty = new Array<Uint8Array>(DEPTH + 1);
  empty[DEPTH] = keccak256(DOMAIN_EMPTY);
  for (let depth = DEPTH - 1; depth >= 0; depth--) {
    const child = empty[depth + 1];
    if (!child) throw new Error("missing empty hash");
    empty[depth] = keccak256(concat(DOMAIN_NODE, child, child));
  }
  return empty;
}

const EMPTY = buildEmpty();

function emptyAt(depth: number): Uint8Array {
  const value = EMPTY[depth];
  if (!value) throw new XimError("INVALID_PROOF", "depth is outside the sparse Merkle tree");
  return value;
}

export function emptyTreeRoot(): Uint8Array {
  return copyBytes(emptyAt(0));
}

export function leafDigest(key: Uint8Array, valueHash: Uint8Array): Uint8Array {
  if (key.length !== 32 || valueHash.length !== 32) {
    throw new XimError("INVALID_PROOF", "leaf inputs must be 32 bytes");
  }
  return keccak256(concat(DOMAIN_LEAF, key, valueHash));
}

function nodeDigest(left: Uint8Array, right: Uint8Array): Uint8Array {
  return keccak256(concat(DOMAIN_NODE, left, right));
}

function combine(hash: Uint8Array, sibling: Uint8Array, bit: number): Uint8Array {
  return bit === 0 ? nodeDigest(hash, sibling) : nodeDigest(sibling, hash);
}

function bitPath(key: Uint8Array): string {
  let path = "";
  for (let index = 0; index < DEPTH; index++) path += getBit(key, index) === 1 ? "1" : "0";
  return path;
}

function nodeKey(depth: number, path: string): string {
  return `${depth}:${path}`;
}

function setBitmapBit(bitmap: Uint8Array, index: number): void {
  const byteIndex = index >> 3;
  const byte = bitmap[byteIndex];
  if (byte === undefined) throw new XimError("INVALID_PROOF", "bitmap overflow");
  bitmap[byteIndex] = byte | (1 << (index & 7));
}

function bitmapBit(bitmap: Uint8Array, index: number): boolean {
  const byte = bitmap[index >> 3];
  if (byte === undefined) return false;
  return (byte & (1 << (index & 7))) !== 0;
}

/** Compact inclusion or absence proof. Default siblings are omitted. */
export interface CompactProof {
  key: Uint8Array;
  /** Null proves the key is absent. */
  valueHash: Uint8Array | null;
  bitmap: Uint8Array;
  siblings: Uint8Array[];
}

export interface ProofJson {
  key: string;
  valueHash: string | null;
  bitmap: string;
  siblings: string[];
}

export class SparseMerkleTree {
  private readonly nodes = new Map<string, Uint8Array>();
  private readonly values = new Map<string, Uint8Array>();
  private rootHash: Uint8Array = copyBytes(emptyAt(0));

  get root(): Uint8Array {
    return copyBytes(this.rootHash);
  }

  get size(): number {
    return this.values.size;
  }

  has(key: Uint8Array): boolean {
    return this.values.has(toHex(key));
  }

  get(key: Uint8Array): Uint8Array | undefined {
    const value = this.values.get(toHex(key));
    return value ? copyBytes(value) : undefined;
  }

  set(key: Uint8Array, valueHash: Uint8Array): void {
    if (key.length !== 32 || valueHash.length !== 32) {
      throw new XimError("INVALID_PROOF", "SMT key and value must be 32 bytes");
    }
    this.values.set(toHex(key), copyBytes(valueHash));
    this.write(key, leafDigest(key, valueHash));
  }

  remove(key: Uint8Array): void {
    if (key.length !== 32) throw new XimError("INVALID_PROOF", "SMT key must be 32 bytes");
    this.values.delete(toHex(key));
    this.write(key, emptyAt(DEPTH));
  }

  prove(key: Uint8Array, presence: "present" | "absent"): CompactProof {
    if (key.length !== 32) throw new XimError("INVALID_PROOF", "SMT key must be 32 bytes");
    const stored = this.values.get(toHex(key));
    if (presence === "present" && !stored) throw new XimError("UNKNOWN_MESSAGE", "key is absent");
    if (presence === "absent" && stored) throw new XimError("NOT_ABSENT", "key is present");
    const path = bitPath(key);
    const bitmap = new Uint8Array(32);
    const siblings: Uint8Array[] = [];
    for (let index = 0; index < DEPTH; index++) {
      const depth = DEPTH - index;
      const bit = path[depth - 1] === "1" ? 1 : 0;
      const parentPath = path.slice(0, depth - 1);
      const siblingPath = parentPath + (bit === 0 ? "1" : "0");
      const sibling = this.nodes.get(nodeKey(depth, siblingPath)) ?? emptyAt(depth);
      if (!bytesEqual(sibling, emptyAt(depth))) {
        setBitmapBit(bitmap, index);
        siblings.push(copyBytes(sibling));
      }
    }
    return {
      key: copyBytes(key),
      valueHash: stored ? copyBytes(stored) : null,
      bitmap,
      siblings,
    };
  }

  private write(key: Uint8Array, startingHash: Uint8Array): void {
    const path = bitPath(key);
    let hash = startingHash;
    if (bytesEqual(hash, emptyAt(DEPTH))) this.nodes.delete(nodeKey(DEPTH, path));
    else this.nodes.set(nodeKey(DEPTH, path), hash);

    for (let depth = DEPTH; depth > 0; depth--) {
      const bit = path[depth - 1] === "1" ? 1 : 0;
      const parentPath = path.slice(0, depth - 1);
      const siblingPath = parentPath + (bit === 0 ? "1" : "0");
      const sibling = this.nodes.get(nodeKey(depth, siblingPath)) ?? emptyAt(depth);
      hash = combine(hash, sibling, bit);
      const parentDepth = depth - 1;
      if (bytesEqual(hash, emptyAt(parentDepth))) this.nodes.delete(nodeKey(parentDepth, parentPath));
      else this.nodes.set(nodeKey(parentDepth, parentPath), hash);
    }
    this.rootHash = hash;
  }
}

export function verifyCompactProof(root: Uint8Array, proof: CompactProof): boolean {
  if (root.length !== 32 || proof.key.length !== 32 || proof.bitmap.length !== 32) return false;
  if (proof.valueHash !== null && proof.valueHash.length !== 32) return false;
  let ones = 0;
  for (let index = 0; index < DEPTH; index++) if (bitmapBit(proof.bitmap, index)) ones += 1;
  if (ones !== proof.siblings.length) return false;
  for (const sibling of proof.siblings) if (sibling.length !== 32) return false;

  let hash = proof.valueHash ? leafDigest(proof.key, proof.valueHash) : emptyAt(DEPTH);
  let cursor = 0;
  for (let index = 0; index < DEPTH; index++) {
    const depth = DEPTH - index;
    const sibling = bitmapBit(proof.bitmap, index) ? proof.siblings[cursor++] : emptyAt(depth);
    if (!sibling) return false;
    hash = combine(hash, sibling, getBit(proof.key, depth - 1));
  }
  return cursor === proof.siblings.length && bytesEqual(hash, root);
}

export function proofToJson(proof: CompactProof): ProofJson {
  return {
    key: toHex(proof.key),
    valueHash: proof.valueHash ? toHex(proof.valueHash) : null,
    bitmap: toHex(proof.bitmap),
    siblings: proof.siblings.map((sibling) => toHex(sibling)),
  };
}

export function proofFromJson(input: unknown): CompactProof {
  if (input === null || typeof input !== "object" || Array.isArray(input)) {
    throw new XimError("INVALID_PROOF", "proof must be an object");
  }
  const record = input as Record<string, unknown>;
  if (typeof record.key !== "string" || typeof record.bitmap !== "string" || !Array.isArray(record.siblings)) {
    throw new XimError("INVALID_PROOF", "proof is missing key, bitmap, or siblings");
  }
  if (record.valueHash !== null && typeof record.valueHash !== "string") {
    throw new XimError("INVALID_PROOF", "valueHash must be hex or null");
  }
  try {
    return {
      key: fromHex(record.key, 32),
      valueHash: typeof record.valueHash === "string" ? fromHex(record.valueHash, 32) : null,
      bitmap: fromHex(record.bitmap, 32),
      siblings: record.siblings.map((sibling) => {
        if (typeof sibling !== "string") throw new XimError("INVALID_PROOF", "sibling must be hex");
        return fromHex(sibling, 32);
      }),
    };
  } catch (error) {
    if (error instanceof XimError && error.code !== "INVALID_PROOF") {
      throw new XimError("INVALID_PROOF", error.message);
    }
    throw error;
  }
}
