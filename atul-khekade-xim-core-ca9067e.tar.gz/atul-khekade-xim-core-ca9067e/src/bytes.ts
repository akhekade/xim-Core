import { XimError } from "./errors.js";

const TEXT = new TextEncoder();

/** Maximum byte length of a length-prefixed XCE-1 string. */
export const MAX_STRING_BYTES = 1024;

export const MAX_U64 = (1n << 64n) - 1n;
export const MAX_U256 = (1n << 256n) - 1n;

export function concat(...parts: readonly Uint8Array[]): Uint8Array {
  let length = 0;
  for (const part of parts) length += part.length;
  const out = new Uint8Array(length);
  let offset = 0;
  for (const part of parts) {
    out.set(part, offset);
    offset += part.length;
  }
  return out;
}

export function copyBytes(bytes: Uint8Array): Uint8Array {
  return new Uint8Array(bytes);
}

export function bytesEqual(left: Uint8Array, right: Uint8Array): boolean {
  if (left.length !== right.length) return false;
  let difference = 0;
  for (let index = 0; index < left.length; index++) {
    difference |= left[index]! ^ right[index]!;
  }
  return difference === 0;
}

export function isZero(bytes: Uint8Array): boolean {
  for (const byte of bytes) if (byte !== 0) return false;
  return true;
}

export function zero32(): Uint8Array {
  return new Uint8Array(32);
}

export function toHex(bytes: Uint8Array): string {
  let hex = "0x";
  for (const byte of bytes) hex += byte.toString(16).padStart(2, "0");
  return hex;
}

export function fromHex(hex: string, length?: number): Uint8Array {
  if (typeof hex !== "string") {
    throw new XimError("INVALID_MESSAGE", "expected a hex string");
  }
  const body = hex.startsWith("0x") || hex.startsWith("0X") ? hex.slice(2) : hex;
  if (body.length % 2 !== 0 || !/^[0-9a-fA-F]*$/.test(body)) {
    throw new XimError("INVALID_MESSAGE", "malformed hex");
  }
  if (length !== undefined && body.length !== length * 2) {
    throw new XimError("INVALID_MESSAGE", `expected ${length} bytes of hex`);
  }
  const out = new Uint8Array(body.length / 2);
  for (let index = 0; index < out.length; index++) {
    out[index] = Number.parseInt(body.slice(index * 2, index * 2 + 2), 16);
  }
  return out;
}

export function encodeU8(value: number): Uint8Array {
  if (!Number.isInteger(value) || value < 0 || value > 255) {
    throw new XimError("OVERFLOW", "uint8 out of range");
  }
  return Uint8Array.of(value);
}

export function encodeU32(value: number): Uint8Array {
  if (!Number.isInteger(value) || value < 0 || value > 0xffffffff) {
    throw new XimError("OVERFLOW", "uint32 out of range");
  }
  const out = new Uint8Array(4);
  new DataView(out.buffer).setUint32(0, value, false);
  return out;
}

export function encodeU64(value: bigint): Uint8Array {
  if (value < 0n || value > MAX_U64) throw new XimError("OVERFLOW", "uint64 out of range");
  const out = new Uint8Array(8);
  const view = new DataView(out.buffer);
  view.setUint32(0, Number(value >> 32n), false);
  view.setUint32(4, Number(value & 0xffffffffn), false);
  return out;
}

export function encodeU256(value: bigint): Uint8Array {
  if (value < 0n || value > MAX_U256) throw new XimError("OVERFLOW", "uint256 out of range");
  const out = new Uint8Array(32);
  let remaining = value;
  for (let index = 31; index >= 0; index--) {
    out[index] = Number(remaining & 0xffn);
    remaining >>= 8n;
  }
  return out;
}

export function encodeString(value: string): Uint8Array {
  const bytes = TEXT.encode(value);
  if (bytes.length > MAX_STRING_BYTES) {
    throw new XimError("INVALID_MESSAGE", "string exceeds 1024 bytes");
  }
  return concat(encodeU32(bytes.length), bytes);
}

export function encodeBytes32(bytes: Uint8Array, field: string): Uint8Array {
  if (bytes.length !== 32) throw new XimError("INVALID_MESSAGE", `${field} must be 32 bytes`);
  return bytes;
}

/** Bit 0 is the most significant bit of the first byte. */
export function getBit(key: Uint8Array, index: number): number {
  if (key.length !== 32 || !Number.isInteger(index) || index < 0 || index > 255) {
    throw new XimError("INVALID_PROOF", "bit index requires a 32-byte key");
  }
  const byte = key[index >> 3];
  if (byte === undefined) throw new XimError("INVALID_PROOF", "bit index out of range");
  return (byte >> (7 - (index & 7))) & 1;
}
