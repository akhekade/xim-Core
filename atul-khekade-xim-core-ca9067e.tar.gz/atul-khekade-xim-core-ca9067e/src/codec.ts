import {
  bytesEqual,
  concat,
  copyBytes,
  encodeBytes32,
  encodeString,
  encodeU32,
  encodeU64,
  encodeU8,
  encodeU256,
  MAX_STRING_BYTES,
} from "./bytes.js";
import {
  DOMAIN_EVENT,
  DOMAIN_ID,
  DOMAIN_MSG,
  DOMAIN_STATE,
} from "./domain.js";
import {
  ACTION_TYPE,
  FINALITY,
  MESSAGE_STATUS,
  PRIVACY,
  PROOF_TYPE,
  parseEnum,
} from "./enums.js";
import { XimError } from "./errors.js";
import { keccak256 } from "./hash.js";
import type { MessageState, XimEvent, XimMessage } from "./types.js";
import { normalizeMessage } from "./validate.js";


class Cursor {
  private offset = 0;

  constructor(private readonly bytes: Uint8Array) {}

  private take(length: number): Uint8Array {
    if (this.offset + length > this.bytes.length) {
      throw new XimError("MALFORMED", "canonical bytes are truncated");
    }
    const slice = this.bytes.subarray(this.offset, this.offset + length);
    this.offset += length;
    return slice;
  }

  readDomain(expected: Uint8Array): void {
    const got = this.take(expected.length);
    if (!bytesEqual(got, expected)) throw new XimError("MALFORMED", "unexpected domain tag");
  }

  readU8(): number {
    return this.take(1)[0]!;
  }

  readU32(): number {
    const bytes = this.take(4);
    return new DataView(bytes.buffer, bytes.byteOffset, 4).getUint32(0, false);
  }

  readU64(): bigint {
    const bytes = this.take(8);
    const view = new DataView(bytes.buffer, bytes.byteOffset, 8);
    return (BigInt(view.getUint32(0, false)) << 32n) + BigInt(view.getUint32(4, false));
  }

  readU256(): bigint {
    let value = 0n;
    for (const byte of this.take(32)) value = (value << 8n) + BigInt(byte);
    return value;
  }

  readBytes(length: number): Uint8Array {
    return copyBytes(this.take(length));
  }

  readString(): string {
    const length = this.readU32();
    if (length > MAX_STRING_BYTES) throw new XimError("MALFORMED", "string exceeds 1024 bytes");
    try {
      return new TextDecoder("utf-8", { fatal: true }).decode(this.take(length));
    } catch {
      throw new XimError("MALFORMED", "string is not valid UTF-8");
    }
  }

  finish(): void {
    if (this.offset !== this.bytes.length) {
      throw new XimError("MALFORMED", "canonical bytes have a trailing suffix");
    }
  }
}

/** Keccak preimage for the message identifier. */
export function messageIdPreimage(message: XimMessage): Uint8Array {
  const normalized = normalizeMessage(message);
  return concat(
    DOMAIN_ID,
    encodeU32(normalized.version),
    encodeString(normalized.source.networkId),
    encodeBytes32(normalized.source.txHash, "source.txHash"),
    encodeString(normalized.destination.networkId),
    encodeString(normalized.source.sender),
    encodeString(normalized.destination.receiver),
    encodeU64(normalized.security.nonce),
    encodeBytes32(normalized.action.payloadHash, "action.payloadHash"),
  );
}

export function messageId(message: XimMessage): Uint8Array {
  return keccak256(messageIdPreimage(message));
}

/** Keccak preimage for the full message commitment. */
export function canonicalMessageBytes(message: XimMessage): Uint8Array {
  const normalized = normalizeMessage(message);
  return concat(
    DOMAIN_MSG,
    encodeU32(normalized.version),
    encodeString(normalized.source.networkId),
    encodeU64(normalized.source.blockHeight),
    encodeBytes32(normalized.source.txHash, "source.txHash"),
    encodeString(normalized.source.sender),
    encodeString(normalized.destination.networkId),
    encodeString(normalized.destination.receiver),
    encodeU8(ACTION_TYPE[normalized.action.type]),
    encodeString(normalized.action.assetId),
    encodeU256(normalized.action.amount),
    encodeBytes32(normalized.action.payloadHash, "action.payloadHash"),
    encodeU64(normalized.security.nonce),
    encodeU64(normalized.security.timestamp),
    encodeU64(normalized.security.expiry),
    encodeU8(FINALITY[normalized.security.finalityRequirement]),
    encodeU8(PROOF_TYPE[normalized.security.proofType]),
    encodeBytes32(normalized.security.proofHash, "security.proofHash"),
    encodeBytes32(normalized.policy.complianceHash, "policy.complianceHash"),
    encodeString(normalized.policy.jurisdiction),
    encodeU8(PRIVACY[normalized.policy.privacy]),
  );
}

export function messageHash(message: XimMessage): Uint8Array {
  return keccak256(canonicalMessageBytes(message));
}

export function decodeMessage(bytes: Uint8Array): XimMessage {
  const cursor = new Cursor(bytes);
  cursor.readDomain(DOMAIN_MSG);
  const message: XimMessage = {
    version: 1,
    source: {
      networkId: "",
      blockHeight: 0n,
      txHash: new Uint8Array(32),
      sender: "",
    },
    destination: { networkId: "", receiver: "" },
    action: {
      type: "TRANSFER",
      assetId: "",
      amount: 0n,
      payloadHash: new Uint8Array(32),
    },
    security: {
      nonce: 0n,
      timestamp: 0n,
      expiry: 0n,
      finalityRequirement: "FINAL",
      proofType: "NONE",
      proofHash: new Uint8Array(32),
    },
    policy: {
      complianceHash: new Uint8Array(32),
      jurisdiction: "",
      privacy: "PUBLIC",
    },
  };
  const version = cursor.readU32();
  if (version !== 1) throw new XimError("INVALID_MESSAGE", "version must be 1");
  message.source.networkId = cursor.readString();
  message.source.blockHeight = cursor.readU64();
  message.source.txHash = cursor.readBytes(32);
  message.source.sender = cursor.readString();
  message.destination.networkId = cursor.readString();
  message.destination.receiver = cursor.readString();
  message.action.type = parseEnum(ACTION_TYPE, cursor.readU8(), "action.type");
  message.action.assetId = cursor.readString();
  message.action.amount = cursor.readU256();
  message.action.payloadHash = cursor.readBytes(32);
  message.security.nonce = cursor.readU64();
  message.security.timestamp = cursor.readU64();
  message.security.expiry = cursor.readU64();
  message.security.finalityRequirement = parseEnum(FINALITY, cursor.readU8(), "security.finalityRequirement");
  message.security.proofType = parseEnum(PROOF_TYPE, cursor.readU8(), "security.proofType");
  message.security.proofHash = cursor.readBytes(32);
  message.policy.complianceHash = cursor.readBytes(32);
  message.policy.jurisdiction = cursor.readString();
  message.policy.privacy = parseEnum(PRIVACY, cursor.readU8(), "policy.privacy");
  cursor.finish();
  return normalizeMessage(message);
}

/** Keccak preimage for a lifecycle state value. */
export function canonicalStateBytes(state: MessageState): Uint8Array {
  const status = parseEnum(MESSAGE_STATUS, state.status, "status");
  if (!Number.isInteger(state.sourceFinality) || state.sourceFinality < 0 || state.sourceFinality > 4) {
    throw new XimError("INVALID_MESSAGE", "sourceFinality must be 0 or a finality code");
  }
  return concat(
    DOMAIN_STATE,
    encodeU8(MESSAGE_STATUS[status]),
    encodeU8(state.sourceFinality),
    encodeBytes32(state.verificationHash, "verificationHash"),
    encodeBytes32(state.executionHash, "executionHash"),
    encodeBytes32(state.destinationTxHash, "destinationTxHash"),
  );
}

export function stateHash(state: MessageState): Uint8Array {
  return keccak256(canonicalStateBytes(state));
}

/** Keccak preimage for one append-only log event. `eventHash` is omitted. */
export function canonicalEventBytes(event: Omit<XimEvent, "eventHash">): Uint8Array {
  const status = parseEnum(MESSAGE_STATUS, event.status, "status");
  return concat(
    DOMAIN_EVENT,
    encodeBytes32(event.previousEventHash, "previousEventHash"),
    encodeBytes32(event.messageId, "messageId"),
    encodeU8(MESSAGE_STATUS[status]),
    encodeString(event.networkId),
    encodeU64(event.blockHeight),
    encodeU64(event.timestamp),
    encodeBytes32(event.previousStateHash, "previousStateHash"),
    encodeBytes32(event.newStateHash, "newStateHash"),
    encodeBytes32(event.proofHash, "proofHash"),
  );
}

export function eventHash(event: Omit<XimEvent, "eventHash">): Uint8Array {
  return keccak256(canonicalEventBytes(event));
}
