#!/usr/bin/env node
import { readFileSync, writeFileSync } from "node:fs";
import path from "node:path";
import { toHex } from "./bytes.js";
import { canonicalMessageBytes, messageHash, messageId, messageIdPreimage } from "./codec.js";
import { runLifecycle, type LifecycleReport } from "./demo.js";
import { XimError } from "./errors.js";
import { parseMessage } from "./validate.js";
import { buildVectors, exampleMessagePath, packageRoot } from "./vectors.js";

function readMessage(file: string) {
  return parseMessage(JSON.parse(readFileSync(file, "utf8")) as unknown);
}

function printReport(report: LifecycleReport): void {
  console.log("XIM v1 demo — 10 USDC units from Ethereum to XDC");
  console.log(`messageId    ${report.messageId}`);
  console.log(`messageHash  ${report.messageHash}`);
  for (const step of report.steps) {
    console.log(`${step.status.padEnd(13)} root ${step.root}`);
  }
  console.log(`inclusion    ${report.inclusionVerified ? "verified" : "failed"}`);
  console.log(`absence      ${report.absenceVerified ? "verified" : "failed"}`);
  console.log(`replay       ${report.replayVerified ? "verified" : "failed"}`);
  console.log(`events       ${report.eventCount}`);
}

function main(): void {
  const [command, ...args] = process.argv.slice(2);
  const asJson = args.includes("--json");
  const file = args.find((argument) => !argument.startsWith("--"));

  if (command === "id" || command === "hash" || command === "encode") {
    if (!file) throw new XimError("INVALID_MESSAGE", `usage: xim ${command} <message.json>`);
    const message = readMessage(file);
    if (command === "id") {
      const id = toHex(messageId(message));
      console.log(asJson ? JSON.stringify({ messageId: id }) : id);
      return;
    }
    if (command === "hash") {
      const hash = toHex(messageHash(message));
      console.log(asJson ? JSON.stringify({ messageHash: hash }) : hash);
      return;
    }
    console.log(
      JSON.stringify(
        {
          messageIdPreimage: toHex(messageIdPreimage(message)),
          messageId: toHex(messageId(message)),
          canonicalMessage: toHex(canonicalMessageBytes(message)),
          messageHash: toHex(messageHash(message)),
        },
        null,
        2,
      ),
    );
    return;
  }

  if (command === "demo") {
    const report = runLifecycle(readMessage(file ?? exampleMessagePath()));
    if (asJson) console.log(JSON.stringify(report, null, 2));
    else printReport(report);
    if (!report.inclusionVerified || !report.absenceVerified || !report.replayVerified) {
      process.exitCode = 1;
    }
    return;
  }

  if (command === "vectors") {
    const target = path.join(packageRoot(), "spec", "test-vectors.json");
    writeFileSync(target, `${JSON.stringify(buildVectors(), null, 2)}\n`);
    console.log(target);
    return;
  }

  console.error("usage: xim <id|hash|encode|demo|vectors> [message.json]");
  process.exitCode = 1;
}

try {
  main();
} catch (error) {
  if (error instanceof XimError) console.error(`${error.code}: ${error.message}`);
  else if (error instanceof Error) console.error(error.message);
  else console.error(String(error));
  process.exitCode = 1;
}
