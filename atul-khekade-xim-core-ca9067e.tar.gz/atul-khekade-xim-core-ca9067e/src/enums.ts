import { XimError } from "./errors.js";

export const MESSAGE_STATUS = {
  CREATED: 1,
  SOURCE_FINAL: 2,
  COMMITTED: 3,
  VERIFIED: 4,
  EXECUTING: 5,
  SETTLED: 6,
  ACKNOWLEDGED: 7,
  FAILED: 8,
  EXPIRED: 9,
  REFUNDED: 10,
} as const;

export const ACTION_TYPE = {
  TRANSFER: 1,
  EXECUTE: 2,
  SETTLE: 3,
  ACK: 4,
  REFUND: 5,
  DATA: 6,
} as const;

/** Ordered. A later observation may raise finality and MUST NOT lower it. */
export const FINALITY = {
  INSTANT: 1,
  CONFIRMED: 2,
  INSTITUTIONAL: 3,
  FINAL: 4,
} as const;

export const PROOF_TYPE = {
  NONE: 0,
  LIGHT_CLIENT: 1,
  ZK_PROOF: 2,
  THRESHOLD_ATTESTATION: 3,
  NATIVE_PROOF: 4,
  TEE_ATTESTATION: 5,
  HYBRID: 6,
} as const;

export const PRIVACY = {
  PUBLIC: 1,
  HASH_ONLY: 2,
  PRIVATE: 3,
} as const;

export type MessageStatusName = keyof typeof MESSAGE_STATUS;
export type ActionName = keyof typeof ACTION_TYPE;
export type FinalityName = keyof typeof FINALITY;
export type ProofTypeName = keyof typeof PROOF_TYPE;
export type PrivacyName = keyof typeof PRIVACY;

export const NEXT_STATUS: Record<MessageStatusName, readonly MessageStatusName[]> = {
  CREATED: ["SOURCE_FINAL", "FAILED", "EXPIRED"],
  SOURCE_FINAL: ["COMMITTED", "FAILED", "EXPIRED"],
  COMMITTED: ["VERIFIED", "FAILED", "EXPIRED"],
  VERIFIED: ["EXECUTING", "FAILED", "EXPIRED"],
  EXECUTING: ["SETTLED", "FAILED"],
  SETTLED: ["ACKNOWLEDGED", "REFUNDED"],
  ACKNOWLEDGED: [],
  FAILED: ["REFUNDED"],
  EXPIRED: ["REFUNDED"],
  REFUNDED: [],
};

/** Statuses from which an expiry timestamp blocks forward progress. */
export const PRE_EXECUTION: readonly MessageStatusName[] = [
  "CREATED",
  "SOURCE_FINAL",
  "COMMITTED",
  "VERIFIED",
];

export const NETWORKS = {
  XDC_MAINNET: "eip155:50",
  XDC_APOTHEM: "eip155:51",
  ETHEREUM: "eip155:1",
  SEPOLIA: "eip155:11155111",
  XIM: "xim:1",
} as const;

export function parseEnum<T extends Record<string, number>>(
  table: T,
  value: unknown,
  field: string,
): keyof T {
  if (typeof value === "string" && Object.prototype.hasOwnProperty.call(table, value)) {
    return value as keyof T;
  }
  if (typeof value === "number" && Number.isInteger(value)) {
    const found = (Object.keys(table) as (keyof T)[]).find((key) => table[key] === value);
    if (found) return found;
  }
  throw new XimError("INVALID_MESSAGE", `${field} is not a recognized value`);
}
