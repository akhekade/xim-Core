import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { toHex } from "./bytes.js";
import {
  canonicalMessageBytes,
  canonicalStateBytes,
  messageHash,
  messageId,
  messageIdPreimage,
} from "./codec.js";
import { runLifecycle } from "./demo.js";
import { DOMAIN } from "./domain.js";
import { initialState } from "./engine.js";
import { keccak256 } from "./hash.js";
import { emptyTreeRoot } from "./smt.js";
import { messageToJson, parseMessage } from "./validate.js";

export function packageRoot(): string {
  return path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
}

export function exampleMessagePath(): string {
  return path.join(packageRoot(), "examples", "usdc-eth-to-xdc.json");
}

/** Known-answer document other XIM implementations can reproduce. */
export function buildVectors(): Record<string, unknown> {
  const messageJson = JSON.parse(readFileSync(exampleMessagePath(), "utf8")) as unknown;
  const message = parseMessage(messageJson);
  const lifecycle = runLifecycle(message);
  return {
    xim: "1",
    hash: "keccak256",
    domains: {
      id: toHex(DOMAIN.id),
      message: toHex(DOMAIN.message),
      state: toHex(DOMAIN.state),
      leaf: toHex(DOMAIN.leaf),
      node: toHex(DOMAIN.node),
      empty: toHex(DOMAIN.empty),
      event: toHex(DOMAIN.event),
    },
    keccakEmpty: toHex(keccak256(new Uint8Array())),
    emptyRoot: toHex(emptyTreeRoot()),
    message: messageToJson(message),
    messageIdPreimage: toHex(messageIdPreimage(message)),
    messageId: toHex(messageId(message)),
    canonicalMessage: toHex(canonicalMessageBytes(message)),
    messageHash: toHex(messageHash(message)),
    createdState: toHex(canonicalStateBytes(initialState())),
    lifecycle,
  };
}
