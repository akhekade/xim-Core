import { bytesEqual, fromHex, toHex } from "./bytes.js";
import { messageHash, messageId } from "./codec.js";
import { NETWORKS, type MessageStatusName } from "./enums.js";
import { XimEngine, replay } from "./engine.js";
import { proofToJson, verifyCompactProof, type ProofJson } from "./smt.js";
import type { ReplayLog, XimMessage } from "./types.js";
import { normalizeMessage } from "./validate.js";

export interface LifecycleStep {
  status: MessageStatusName;
  root: string;
  stateHash: string;
  eventHash: string;
}

/** Result of the illustrative Ethereum-to-XDC settlement lifecycle. */
export interface LifecycleReport {
  messageId: string;
  messageHash: string;
  steps: LifecycleStep[];
  inclusionVerified: boolean;
  absenceVerified: boolean;
  replayVerified: boolean;
  eventCount: number;
  finalRoot: string;
  inclusionProof: ProofJson;
  log: ReplayLog;
}

/**
 * Walk one transfer from creation through acknowledgement and check the
 * inclusion proof, an absence proof, and a full replay of the audit log.
 */
export function runLifecycle(raw: XimMessage): LifecycleReport {
  const message = normalizeMessage(raw);
  const engine = new XimEngine();
  const created = engine.create(message);
  const steps: LifecycleStep[] = [
    {
      status: "CREATED",
      root: toHex(created.root),
      stateHash: toHex(created.stateHash),
      eventHash: toHex(created.eventHash),
    },
  ];

  const origin = message.security.timestamp;
  const sourceBlock = message.source.blockHeight;
  const verification = fromHex(`0x${"11".repeat(32)}`);
  const execution = fromHex(`0x${"22".repeat(32)}`);
  const destinationTx = fromHex(`0x${"33".repeat(32)}`);
  const transitions = [
    {
      status: "SOURCE_FINAL" as const,
      networkId: message.source.networkId,
      blockHeight: sourceBlock + 12n,
      timestamp: origin + 12n,
      sourceFinality: "FINAL" as const,
    },
    {
      status: "COMMITTED" as const,
      networkId: NETWORKS.XIM,
      blockHeight: 1n,
      timestamp: origin + 13n,
    },
    {
      status: "VERIFIED" as const,
      networkId: NETWORKS.XIM,
      blockHeight: 1n,
      timestamp: origin + 14n,
      verificationHash: verification,
      proofHash: verification,
    },
    {
      status: "EXECUTING" as const,
      networkId: message.destination.networkId,
      blockHeight: 90_000_000n,
      timestamp: origin + 15n,
      executionHash: execution,
    },
    {
      status: "SETTLED" as const,
      networkId: message.destination.networkId,
      blockHeight: 90_000_001n,
      timestamp: origin + 16n,
      destinationTxHash: destinationTx,
    },
    {
      status: "ACKNOWLEDGED" as const,
      networkId: message.source.networkId,
      blockHeight: sourceBlock + 20n,
      timestamp: origin + 20n,
    },
  ];

  for (const transition of transitions) {
    const result = engine.transition(created.messageId, transition);
    steps.push({
      status: result.status,
      root: toHex(result.root),
      stateHash: toHex(result.stateHash),
      eventHash: toHex(result.eventHash),
    });
  }

  const proof = engine.inclusionProof(created.messageId);
  const absence = engine.absenceProof(fromHex(`0x${"ff".repeat(32)}`));
  const log = engine.exportLog();
  const replayed = replay(log);
  const originalEvents = engine.events();
  const replayedEvents = replayed.events();
  const replayVerified =
    bytesEqual(engine.root, replayed.root) &&
    originalEvents.length === replayedEvents.length &&
    originalEvents.every((event, index) => bytesEqual(event.eventHash, replayedEvents[index]!.eventHash));

  return {
    messageId: toHex(messageId(message)),
    messageHash: toHex(messageHash(message)),
    steps,
    inclusionVerified: verifyCompactProof(engine.root, proof),
    absenceVerified: verifyCompactProof(engine.root, absence),
    replayVerified,
    eventCount: engine.eventCount,
    finalRoot: toHex(engine.root),
    inclusionProof: proofToJson(proof),
    log,
  };
}
