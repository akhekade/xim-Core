import type {
  ActionName,
  FinalityName,
  MessageStatusName,
  PrivacyName,
  ProofTypeName,
} from "./enums.js";

/** Parsed, normalized XIM v1 message. Integers are bigints and parties are normalized. */
export interface XimMessage {
  version: 1;
  source: {
    networkId: string;
    blockHeight: bigint;
    txHash: Uint8Array;
    sender: string;
  };
  destination: {
    networkId: string;
    receiver: string;
  };
  action: {
    type: ActionName;
    assetId: string;
    amount: bigint;
    payloadHash: Uint8Array;
  };
  security: {
    nonce: bigint;
    timestamp: bigint;
    expiry: bigint;
    finalityRequirement: FinalityName;
    proofType: ProofTypeName;
    proofHash: Uint8Array;
  };
  policy: {
    complianceHash: Uint8Array;
    jurisdiction: string;
    privacy: PrivacyName;
  };
}

/** JSON interchange form. Canonical documents use decimal strings for integers. */
export interface MessageJson {
  version: 1;
  source: {
    networkId: string;
    blockHeight: number | string;
    txHash: string;
    sender: string;
  };
  destination: {
    networkId: string;
    receiver: string;
  };
  action: {
    type: ActionName | number;
    assetId: string;
    amount: number | string;
    payloadHash: string;
  };
  security: {
    nonce: number | string;
    timestamp: number | string;
    expiry: number | string;
    finalityRequirement: FinalityName | number;
    proofType: ProofTypeName | number;
    proofHash: string;
  };
  policy: {
    complianceHash: string;
    jurisdiction: string;
    privacy: PrivacyName | number;
  };
}

/** Lifecycle record committed in the sparse Merkle tree. */
export interface MessageState {
  status: MessageStatusName;
  /** 0 until the source chain is observed. Otherwise a FINALITY code. */
  sourceFinality: number;
  verificationHash: Uint8Array;
  executionHash: Uint8Array;
  destinationTxHash: Uint8Array;
}

export interface TransitionInput {
  status: MessageStatusName;
  networkId: string;
  blockHeight: bigint;
  timestamp: bigint;
  sourceFinality?: FinalityName;
  verificationHash?: Uint8Array;
  executionHash?: Uint8Array;
  destinationTxHash?: Uint8Array;
  proofHash?: Uint8Array;
}

export interface TransitionJson {
  status: MessageStatusName | number;
  networkId: string;
  blockHeight: number | string;
  timestamp: number | string;
  sourceFinality?: FinalityName | number;
  verificationHash?: string;
  executionHash?: string;
  destinationTxHash?: string;
  proofHash?: string;
}

export interface XimEvent {
  eventHash: Uint8Array;
  previousEventHash: Uint8Array;
  messageId: Uint8Array;
  status: MessageStatusName;
  networkId: string;
  blockHeight: bigint;
  timestamp: bigint;
  previousStateHash: Uint8Array;
  newStateHash: Uint8Array;
  proofHash: Uint8Array;
}

export interface MessageView {
  message: XimMessage;
  messageId: Uint8Array;
  messageHash: Uint8Array;
  state: MessageState;
  stateHash: Uint8Array;
}

export interface CreateResult {
  messageId: Uint8Array;
  messageHash: Uint8Array;
  stateHash: Uint8Array;
  eventHash: Uint8Array;
  root: Uint8Array;
}

export interface TransitionResult {
  messageId: Uint8Array;
  status: MessageStatusName;
  stateHash: Uint8Array;
  eventHash: Uint8Array;
  root: Uint8Array;
}

export type ReplayEntry =
  | { kind: "create"; message: MessageJson }
  | { kind: "transition"; messageId: string; transition: TransitionJson };

export interface ReplayLog {
  xim: "1";
  entries: ReplayEntry[];
}
