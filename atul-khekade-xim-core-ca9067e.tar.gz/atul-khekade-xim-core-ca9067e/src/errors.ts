/** Error raised when a message, transition, proof, or log fails XIM v1 rules. */
export class XimError extends Error {
  readonly code: string;

  constructor(code: string, message: string) {
    super(message);
    this.name = "XimError";
    this.code = code;
  }
}
