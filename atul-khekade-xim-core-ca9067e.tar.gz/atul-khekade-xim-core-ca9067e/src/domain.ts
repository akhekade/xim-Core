const TEXT = new TextEncoder();

function tag(ascii: string): Uint8Array {
  const bytes = TEXT.encode(ascii);
  if (bytes.length !== 8) {
    throw new Error(`XIM domain tag must be 8 bytes: ${ascii}`);
  }
  return bytes;
}

/** 8-byte domain separators. See spec/XIM-v1.md. */
export const DOMAIN_ID = tag("XIMID\x01\x00\x00");
export const DOMAIN_MSG = tag("XIMMSG\x01\x00");
export const DOMAIN_STATE = tag("XIMSTA\x01\x00");
export const DOMAIN_LEAF = tag("XIMLEAF\x01");
export const DOMAIN_NODE = tag("XIMNODE\x01");
export const DOMAIN_EMPTY = tag("XIMEMPTY");
export const DOMAIN_EVENT = tag("XIMEVT\x01\x00");

export const DOMAIN = {
  id: DOMAIN_ID,
  message: DOMAIN_MSG,
  state: DOMAIN_STATE,
  leaf: DOMAIN_LEAF,
  node: DOMAIN_NODE,
  empty: DOMAIN_EMPTY,
  event: DOMAIN_EVENT,
} as const;
