import { MAX_U64, bytesEqual, copyBytes, fromHex, isZero, toHex, zero32 } from "./bytes.js";
import { eventHash, messageHash, messageId, stateHash } from "./codec.js";
import { FINALITY, MESSAGE_STATUS, NEXT_STATUS, PRE_EXECUTION, parseEnum } from "./enums.js";
import { XimError } from "./errors.js";
import { SparseMerkleTree, type CompactProof } from "./smt.js";
import type {
  CreateResult,
  MessageJson,
  MessageState,
  MessageView,
  ReplayLog,
  TransitionInput,
  TransitionResult,
  XimEvent,
  XimMessage,
} from "./types.js";
import {
  assertNetworkId,
  cloneMessage,
  isXimMessage,
  messageToJson,
  parseMessage,
  parseTransition,
  parseUint,
  transitionToJson,
} from "./validate.js";

interface StoredMessage {
  message: XimMessage;
  messageId: Uint8Array;
  messageHash: Uint8Array;
  state: MessageState;
  lastTimestamp: bigint;
}

/** State written when a message is first accepted. */
export function initialState(): MessageState {
  return {
    status: "CREATED",
    sourceFinality: 0,
    verificationHash: zero32(),
    executionHash: zero32(),
    destinationTxHash: zero32(),
  };
}

function cloneState(state: MessageState): MessageState {
  return {
    status: state.status,
    sourceFinality: state.sourceFinality,
    verificationHash: copyBytes(state.verificationHash),
    executionHash: copyBytes(state.executionHash),
    destinationTxHash: copyBytes(state.destinationTxHash),
  };
}

function cloneEvent(event: XimEvent): XimEvent {
  return {
    eventHash: copyBytes(event.eventHash),
    previousEventHash: copyBytes(event.previousEventHash),
    messageId: copyBytes(event.messageId),
    status: event.status,
    networkId: event.networkId,
    blockHeight: event.blockHeight,
    timestamp: event.timestamp,
    previousStateHash: copyBytes(event.previousStateHash),
    newStateHash: copyBytes(event.newStateHash),
    proofHash: copyBytes(event.proofHash),
  };
}

function assignHash(current: Uint8Array, next: Uint8Array | undefined, field: string): Uint8Array {
  if (next === undefined) return current;
  if (next.length !== 32) throw new XimError("INVALID_MESSAGE", `${field} must be 32 bytes`);
  if (isZero(current) || bytesEqual(current, next)) return copyBytes(next);
  throw new XimError("HASH_CONFLICT", `${field} is already committed`);
}

/**
 * In-memory XIM v1 engine: message acceptance, lifecycle transitions,
 * an append-only event log, and a sparse Merkle commitment to current state.
 */
export class XimEngine {
  private readonly tree = new SparseMerkleTree();
  private readonly records = new Map<string, StoredMessage>();
  private readonly order: string[] = [];
  private readonly eventLog: XimEvent[] = [];
  private readonly entries: ReplayLog["entries"] = [];
  private tip = zero32();

  get root(): Uint8Array {
    return this.tree.root;
  }

  get eventCount(): number {
    return this.eventLog.length;
  }

  create(input: XimMessage | MessageJson): CreateResult {
    const message = cloneMessage(isXimMessage(input) ? input : parseMessage(input));
    const id = messageId(message);
    const idHex = toHex(id);
    if (this.records.has(idHex)) {
      throw new XimError(
        "DUPLICATE_MESSAGE",
        "message id already exists; amount and policy sit outside the id, so a distinct nonce is required",
      );
    }
    const digest = messageHash(message);
    const state = initialState();
    const digestState = stateHash(state);
    this.tree.set(id, digestState);
    const event = this.appendEvent({
      messageId: id,
      status: "CREATED",
      networkId: message.source.networkId,
      blockHeight: message.source.blockHeight,
      timestamp: message.security.timestamp,
      previousStateHash: zero32(),
      newStateHash: digestState,
      proofHash: digest,
    });
    this.records.set(idHex, {
      message,
      messageId: copyBytes(id),
      messageHash: copyBytes(digest),
      state,
      lastTimestamp: message.security.timestamp,
    });
    this.order.push(idHex);
    this.entries.push({ kind: "create", message: messageToJson(message) });
    return {
      messageId: copyBytes(id),
      messageHash: copyBytes(digest),
      stateHash: copyBytes(digestState),
      eventHash: copyBytes(event.eventHash),
      root: this.root,
    };
  }

  transition(messageIdBytes: Uint8Array, input: TransitionInput): TransitionResult {
    if (messageIdBytes.length !== 32) {
      throw new XimError("INVALID_MESSAGE", "messageId must be 32 bytes");
    }
    const idHex = toHex(messageIdBytes);
    const record = this.records.get(idHex);
    if (!record) throw new XimError("UNKNOWN_MESSAGE", "message id is not in this engine");
    const nextState = this.evolve(record, input);
    const nextStateHash = stateHash(nextState);
    this.tree.set(record.messageId, nextStateHash);
    const root = this.root;
    const proofHash = input.proofHash
      ? copyBytes(input.proofHash)
      : input.status === "COMMITTED"
        ? root
        : zero32();
    const event = this.appendEvent({
      messageId: record.messageId,
      status: input.status,
      networkId: input.networkId,
      blockHeight: input.blockHeight,
      timestamp: input.timestamp,
      previousStateHash: stateHash(record.state),
      newStateHash: nextStateHash,
      proofHash,
    });
    record.state = nextState;
    record.lastTimestamp = input.timestamp;
    this.entries.push({
      kind: "transition",
      messageId: idHex,
      transition: transitionToJson(input),
    });
    return {
      messageId: copyBytes(record.messageId),
      status: input.status,
      stateHash: copyBytes(nextStateHash),
      eventHash: copyBytes(event.eventHash),
      root,
    };
  }

  get(messageIdBytes: Uint8Array): MessageView | undefined {
    const record = this.records.get(toHex(messageIdBytes));
    if (!record) return undefined;
    const state = cloneState(record.state);
    return {
      message: cloneMessage(record.message),
      messageId: copyBytes(record.messageId),
      messageHash: copyBytes(record.messageHash),
      state,
      stateHash: stateHash(state),
    };
  }

  list(): Uint8Array[] {
    return this.order.map((idHex) => {
      const record = this.records.get(idHex);
      if (!record) throw new XimError("TAMPERED_LOG", "message index is missing");
      return copyBytes(record.messageId);
    });
  }

  events(): XimEvent[] {
    return this.eventLog.map(cloneEvent);
  }

  exportLog(): ReplayLog {
    return JSON.parse(JSON.stringify({ xim: "1", entries: this.entries })) as ReplayLog;
  }

  inclusionProof(messageIdBytes: Uint8Array): CompactProof {
    return this.tree.prove(messageIdBytes, "present");
  }

  absenceProof(messageIdBytes: Uint8Array): CompactProof {
    return this.tree.prove(messageIdBytes, "absent");
  }

  private evolve(record: StoredMessage, input: TransitionInput): MessageState {
    const from = record.state.status;
    const status = parseEnum(MESSAGE_STATUS, input.status, "status");
    if (status === "CREATED" || !NEXT_STATUS[from].includes(status)) {
      throw new XimError("ILLEGAL_TRANSITION", `${from} cannot transition to ${status}`);
    }
    const networkId = assertNetworkId(input.networkId, "networkId");
    const blockHeight = parseUint(input.blockHeight, MAX_U64, "blockHeight");
    const timestamp = parseUint(input.timestamp, MAX_U64, "timestamp");
    if (timestamp < record.lastTimestamp) {
      throw new XimError("INVALID_MESSAGE", "timestamp is earlier than the previous observation");
    }
    if (
      networkId === record.message.source.networkId &&
      blockHeight < record.message.source.blockHeight
    ) {
      throw new XimError("INVALID_MESSAGE", "block height is below the source block");
    }
    if (status === "SOURCE_FINAL" && networkId !== record.message.source.networkId) {
      throw new XimError("INVALID_MESSAGE", "SOURCE_FINAL must be observed on the source network");
    }
    if (status === "ACKNOWLEDGED" && networkId !== record.message.source.networkId) {
      throw new XimError("INVALID_MESSAGE", "ACKNOWLEDGED must be observed on the source network");
    }
    if (
      (status === "EXECUTING" || status === "SETTLED") &&
      networkId !== record.message.destination.networkId
    ) {
      throw new XimError("INVALID_MESSAGE", `${status} must be observed on the destination network`);
    }
    const beforeExecution = PRE_EXECUTION.includes(from);
    if (
      beforeExecution &&
      timestamp >= record.message.security.expiry &&
      status !== "EXPIRED" &&
      status !== "FAILED"
    ) {
      throw new XimError("MESSAGE_EXPIRED", "the message is past expiry");
    }
    if (status === "EXPIRED" && timestamp < record.message.security.expiry) {
      throw new XimError("INVALID_MESSAGE", "EXPIRED requires a timestamp at or after expiry");
    }
    if (status === "SOURCE_FINAL") {
      if (!input.sourceFinality) {
        throw new XimError("INVALID_MESSAGE", "SOURCE_FINAL requires sourceFinality");
      }
      if (FINALITY[input.sourceFinality] < FINALITY.CONFIRMED) {
        throw new XimError(
          "INVALID_MESSAGE",
          "SOURCE_FINAL requires confirmed, institutional, or final finality",
        );
      }
    }
    if (status === "VERIFIED" && (!input.verificationHash || isZero(input.verificationHash))) {
      throw new XimError("INVALID_MESSAGE", "VERIFIED requires a verification hash");
    }
    if (status === "SETTLED" && (!input.destinationTxHash || isZero(input.destinationTxHash))) {
      throw new XimError("INVALID_MESSAGE", "SETTLED requires a destination transaction hash");
    }
    if (input.proofHash && input.proofHash.length !== 32) {
      throw new XimError("INVALID_MESSAGE", "proofHash must be 32 bytes");
    }

    return {
      status,
      sourceFinality: assignFinality(record.state.sourceFinality, input.sourceFinality),
      verificationHash: assignHash(record.state.verificationHash, input.verificationHash, "verificationHash"),
      executionHash: assignHash(record.state.executionHash, input.executionHash, "executionHash"),
      destinationTxHash: assignHash(
        record.state.destinationTxHash,
        input.destinationTxHash,
        "destinationTxHash",
      ),
    };
  }

  private appendEvent(partial: Omit<XimEvent, "eventHash" | "previousEventHash">): XimEvent {
    const body = { ...partial, previousEventHash: copyBytes(this.tip) };
    const event: XimEvent = { ...body, eventHash: eventHash(body) };
    this.eventLog.push(event);
    this.tip = event.eventHash;
    return event;
  }
}

function assignFinality(current: number, next: TransitionInput["sourceFinality"]): number {
  if (next === undefined) return current;
  const code = FINALITY[next];
  if (code < current) throw new XimError("FINALITY_REGRESSION", "source finality cannot decrease");
  return code;
}

/** Rebuild an engine from the caller-supplied replay log. */
export function replay(log: ReplayLog): XimEngine {
  if (log.xim !== "1" || !Array.isArray(log.entries)) {
    throw new XimError("TAMPERED_LOG", "replay log must be XIM version 1");
  }
  const engine = new XimEngine();
  for (const entry of log.entries) {
    if (entry.kind === "create") engine.create(entry.message);
    else if (entry.kind === "transition") {
      engine.transition(fromHex(entry.messageId, 32), parseTransition(entry.transition));
    } else throw new XimError("TAMPERED_LOG", "replay entry kind is not recognized");
  }
  return engine;
}

/**
 * Check that an event list is internally hash-linked and that each message
 * follows the lifecycle. This does not recompute state hashes from message bodies.
 */
export function verifyEventChain(events: readonly XimEvent[]): void {
  let previous = zero32();
  const latest = new Map<string, { status: XimEvent["status"]; stateHash: Uint8Array }>();
  for (let index = 0; index < events.length; index++) {
    const event = events[index];
    if (!event) throw new XimError("TAMPERED_LOG", "missing event");
    if (!bytesEqual(event.previousEventHash, previous)) {
      throw new XimError("TAMPERED_LOG", `event ${index} breaks the hash chain`);
    }
    if (!bytesEqual(event.eventHash, eventHash(event))) {
      throw new XimError("TAMPERED_LOG", `event ${index} hash does not match its fields`);
    }
    const key = toHex(event.messageId);
    const prior = latest.get(key);
    if (!prior) {
      if (event.status !== "CREATED") {
        throw new XimError("TAMPERED_LOG", "the first event for a message must be CREATED");
      }
      if (!isZero(event.previousStateHash)) {
        throw new XimError("TAMPERED_LOG", "CREATED must start from the zero state hash");
      }
    } else {
      if (!bytesEqual(prior.stateHash, event.previousStateHash)) {
        throw new XimError("TAMPERED_LOG", "state hash link is broken");
      }
      if (!NEXT_STATUS[prior.status].includes(event.status)) {
        throw new XimError("TAMPERED_LOG", "event status is not a legal transition");
      }
    }
    latest.set(key, { status: event.status, stateHash: event.newStateHash });
    previous = event.eventHash;
  }
}
