import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, it } from "node:test";
import { buildVectors } from "../src/vectors.js";

const vectorPath = path.join(import.meta.dirname, "../spec/test-vectors.json");

describe("test vectors", () => {
  it("matches the committed known-answer file", () => {
    const committed = JSON.parse(readFileSync(vectorPath, "utf8")) as {
      keccakEmpty: string;
      messageId: string;
      emptyRoot: string;
      lifecycle: { inclusionVerified: boolean; replayVerified: boolean };
    };
    assert.deepEqual(buildVectors(), committed);
    assert.equal(committed.keccakEmpty, "0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470");
    assert.equal(committed.messageId, "0x362e59dae747f314d04e8755b5262c17650946499e6a87e5d6fff82b17a09d80");
    assert.equal(committed.lifecycle.inclusionVerified, true);
    assert.equal(committed.lifecycle.replayVerified, true);
    assert.match(committed.emptyRoot, /^0x[0-9a-f]{64}$/);
  });
});
