import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, it } from "node:test";
import { toHex } from "../src/bytes.js";
import { XimEngine, replay, verifyEventChain } from "../src/engine.js";
import { XimError } from "../src/errors.js";
import { verifyCompactProof } from "../src/smt.js";
import type { TransitionInput, XimMessage } from "../src/types.js";
import { parseMessage } from "../src/validate.js";

const examplePath = path.join(import.meta.dirname, "../examples/usdc-eth-to-xdc.json");

function message(patch?: (json: Record<string, unknown>) => void): XimMessage {
  const json = JSON.parse(readFileSync(examplePath, "utf8")) as Record<string, unknown>;
  patch?.(json);
  return parseMessage(json);
}

function sourceFinal(messageId: Uint8Array, body: XimMessage, engine: XimEngine) {
  return engine.transition(messageId, {
    status: "SOURCE_FINAL",
    networkId: body.source.networkId,
    blockHeight: body.source.blockHeight + 12n,
    timestamp: body.security.timestamp + 12n,
    sourceFinality: "FINAL",
  });
}

describe("XIM engine", () => {
  it("commits the message hash in the CREATED event and rejects a duplicate id", () => {
    const engine = new XimEngine();
    const body = message();
    const created = engine.create(body);
    const createdEvent = engine.events()[0];
    assert.ok(createdEvent);
    assert.equal(toHex(createdEvent.proofHash), toHex(created.messageHash));
    assert.equal(verifyCompactProof(engine.root, engine.inclusionProof(created.messageId)), true);
    assert.throws(() => engine.create(message((json) => {
      (json.action as { amount: string }).amount = "1";
    })), (error: unknown) => {
      assert.ok(error instanceof XimError);
      assert.equal(error.code, "DUPLICATE_MESSAGE");
      return true;
    });
  });

  it("uses the post-transition root as the default COMMITTED proof", () => {
    const engine = new XimEngine();
    const body = message();
    const created = engine.create(body);
    sourceFinal(created.messageId, body, engine);
    const committed = engine.transition(created.messageId, {
      status: "COMMITTED",
      networkId: "xim:1",
      blockHeight: 1n,
      timestamp: body.security.timestamp + 13n,
    });
    const event = engine.events().at(-1);
    assert.ok(event);
    assert.equal(toHex(event.proofHash), toHex(committed.root));
  });

  it("enforces the lifecycle, finality, expiry, and network rules", () => {
    const body = message();
    const engine = new XimEngine();
    const created = engine.create(body);
    const id = created.messageId;
    const base = {
      networkId: body.source.networkId,
      blockHeight: body.source.blockHeight,
      timestamp: body.security.timestamp + 1n,
    };

    assert.throws(
      () => engine.transition(id, { ...base, status: "COMMITTED" }),
      (error: unknown) => error instanceof XimError && error.code === "ILLEGAL_TRANSITION",
    );
    assert.throws(
      () => engine.transition(id, { ...base, status: "SOURCE_FINAL", sourceFinality: "INSTANT" }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );
    assert.throws(
      () =>
        engine.transition(id, {
          ...base,
          status: "SOURCE_FINAL",
          sourceFinality: "FINAL",
          networkId: body.destination.networkId,
          blockHeight: 1n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );
    assert.throws(
      () =>
        engine.transition(id, {
          status: "SOURCE_FINAL",
          sourceFinality: "FINAL",
          networkId: body.source.networkId,
          blockHeight: body.source.blockHeight - 1n,
          timestamp: body.security.timestamp + 1n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );

    sourceFinal(id, body, engine);
    assert.throws(
      () =>
        engine.transition(id, {
          status: "COMMITTED",
          networkId: "xim:1",
          blockHeight: 1n,
          timestamp: body.security.timestamp + 1n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );

    const expiredBody = message((json) => {
      const security = json.security as { timestamp: string; expiry: string };
      security.timestamp = "1000";
      security.expiry = "2000";
    });
    const expiredEngine = new XimEngine();
    const expired = expiredEngine.create(expiredBody);
    assert.throws(
      () =>
        expiredEngine.transition(expired.messageId, {
          status: "EXPIRED",
          networkId: expiredBody.source.networkId,
          blockHeight: expiredBody.source.blockHeight,
          timestamp: 1999n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );
    assert.throws(
      () =>
        expiredEngine.transition(expired.messageId, {
          status: "SOURCE_FINAL",
          sourceFinality: "CONFIRMED",
          networkId: expiredBody.source.networkId,
          blockHeight: expiredBody.source.blockHeight,
          timestamp: 2000n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "MESSAGE_EXPIRED",
    );
    expiredEngine.transition(expired.messageId, {
      status: "EXPIRED",
      networkId: expiredBody.source.networkId,
      blockHeight: expiredBody.source.blockHeight,
      timestamp: 2000n,
    });
    assert.equal(expiredEngine.get(expired.messageId)?.state.status, "EXPIRED");
  });

  it("settles on the destination chain and refuses to overwrite the destination transaction", () => {
    const body = message();
    const engine = new XimEngine();
    const created = engine.create(body);
    const id = created.messageId;
    sourceFinal(id, body, engine);
    engine.transition(id, {
      status: "COMMITTED",
      networkId: "xim:1",
      blockHeight: 1n,
      timestamp: body.security.timestamp + 13n,
    });
    assert.throws(
      () =>
        engine.transition(id, {
          status: "VERIFIED",
          networkId: "xim:1",
          blockHeight: 1n,
          timestamp: body.security.timestamp + 14n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );
    const verification = new Uint8Array(32);
    verification[0] = 1;
    engine.transition(id, {
      status: "VERIFIED",
      networkId: "xim:1",
      blockHeight: 1n,
      timestamp: body.security.timestamp + 14n,
      verificationHash: verification,
    });
    assert.throws(
      () =>
        engine.transition(id, {
          status: "EXECUTING",
          networkId: body.source.networkId,
          blockHeight: body.source.blockHeight + 13n,
          timestamp: body.security.timestamp + 15n,
        }),
      (error: unknown) => error instanceof XimError && error.code === "INVALID_MESSAGE",
    );
    engine.transition(id, {
      status: "EXECUTING",
      networkId: body.destination.networkId,
      blockHeight: 10n,
      timestamp: body.security.timestamp + 15n,
    });
    const destinationTx = new Uint8Array(32);
    destinationTx[0] = 2;
    engine.transition(id, {
      status: "SETTLED",
      networkId: body.destination.networkId,
      blockHeight: 11n,
      timestamp: body.security.timestamp + 16n,
      destinationTxHash: destinationTx,
    });
    const refundTx = new Uint8Array(32);
    refundTx[0] = 3;
    assert.throws(
      () =>
        engine.transition(id, {
          status: "REFUNDED",
          networkId: body.destination.networkId,
          blockHeight: 12n,
          timestamp: body.security.timestamp + 17n,
          destinationTxHash: refundTx,
        } satisfies TransitionInput),
      (error: unknown) => error instanceof XimError && error.code === "HASH_CONFLICT",
    );
    engine.transition(id, {
      status: "REFUNDED",
      networkId: "xim:1",
      blockHeight: 2n,
      timestamp: body.security.timestamp + 17n,
      proofHash: refundTx,
    });
    assert.equal(engine.get(id)?.state.status, "REFUNDED");
    assert.equal(toHex(engine.get(id)!.state.destinationTxHash), toHex(destinationTx));
  });

  it("replays the audit log and detects a broken event hash", () => {
    const engine = new XimEngine();
    const body = message();
    const created = engine.create(body);
    sourceFinal(created.messageId, body, engine);
    verifyEventChain(engine.events());
    const replayed = replay(engine.exportLog());
    assert.equal(toHex(replayed.root), toHex(engine.root));
    assert.equal(toHex(replayed.events()[1]!.eventHash), toHex(engine.events()[1]!.eventHash));

    const tampered = engine.events();
    const first = tampered[0];
    assert.ok(first);
    first.eventHash[0] ^= 0xff;
    assert.throws(() => verifyEventChain(tampered), (error: unknown) => {
      assert.ok(error instanceof XimError);
      assert.equal(error.code, "TAMPERED_LOG");
      return true;
    });
  });
});
