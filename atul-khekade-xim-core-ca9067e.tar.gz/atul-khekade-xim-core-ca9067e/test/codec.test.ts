import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, it } from "node:test";
import { toHex } from "../src/bytes.js";
import {
  canonicalMessageBytes,
  decodeMessage,
  messageHash,
  messageId,
} from "../src/codec.js";
import { XimError } from "../src/errors.js";
import { keccak256 } from "../src/hash.js";
import { messageToJson, parseMessage } from "../src/validate.js";

const examplePath = path.join(import.meta.dirname, "../examples/usdc-eth-to-xdc.json");

function example(): ReturnType<typeof parseMessage> {
  return parseMessage(JSON.parse(readFileSync(examplePath, "utf8")) as unknown);
}

function withAmount(amount: string) {
  const json = JSON.parse(readFileSync(examplePath, "utf8")) as { action: { amount: string } };
  json.action.amount = amount;
  return parseMessage(json);
}

describe("canonical messages", () => {
  it("matches the Ethereum empty-string Keccak vector", () => {
    assert.equal(
      toHex(keccak256(new Uint8Array())),
      "0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470",
    );
  });

  it("normalizes XDC and 0x spellings to the same message id", () => {
    const xdc = example();
    const prefixed = parseMessage({
      ...JSON.parse(readFileSync(examplePath, "utf8")),
      destination: {
        networkId: "eip155:50",
        receiver: "0x2222222222222222222222222222222222222222",
      },
    });
    assert.equal(xdc.destination.receiver, "0x2222222222222222222222222222222222222222");
    assert.equal(toHex(messageId(xdc)), toHex(messageId(prefixed)));
  });

  it("keeps the message id stable when only the amount changes", () => {
    const first = example();
    const second = withAmount("10000001");
    assert.equal(toHex(messageId(first)), toHex(messageId(second)));
    assert.notEqual(toHex(messageHash(first)), toHex(messageHash(second)));
  });

  it("changes the message id when the nonce changes", () => {
    const json = JSON.parse(readFileSync(examplePath, "utf8")) as { security: { nonce: string } };
    json.security.nonce = "2";
    assert.notEqual(toHex(messageId(example())), toHex(messageId(parseMessage(json))));
  });

  it("round-trips canonical bytes", () => {
    const message = example();
    assert.deepEqual(decodeMessage(canonicalMessageBytes(message)), message);
  });

  it("rejects truncated and trailing canonical bytes", () => {
    const bytes = canonicalMessageBytes(example());
    assert.throws(() => decodeMessage(bytes.subarray(0, bytes.length - 1)), (error: unknown) => {
      assert.ok(error instanceof XimError);
      assert.equal(error.code, "MALFORMED");
      return true;
    });
    const trailing = new Uint8Array(bytes.length + 1);
    trailing.set(bytes);
    assert.throws(() => decodeMessage(trailing), (error: unknown) => {
      assert.ok(error instanceof XimError);
      assert.equal(error.code, "MALFORMED");
      return true;
    });
  });

  it("rejects unknown JSON fields, a bad version, and an inverted expiry", () => {
    const json = JSON.parse(readFileSync(examplePath, "utf8")) as Record<string, unknown>;
    assert.throws(() => parseMessage({ ...json, extra: true }), XimError);
    assert.throws(() => parseMessage({ ...json, version: 2 }), XimError);
    const expired = structuredClone(json) as { security: { timestamp: string; expiry: string } };
    expired.security.expiry = expired.security.timestamp;
    assert.throws(() => parseMessage(expired), XimError);
  });

  it("emits canonical JSON with normalized parties and decimal strings", () => {
    const json = messageToJson(example());
    assert.equal(json.destination.receiver, "0x2222222222222222222222222222222222222222");
    assert.equal(json.action.amount, "10000000");
    assert.deepEqual(messageToJson(parseMessage(json)), json);
  });

  it("rejects a bare chain name as a network id", () => {
    const json = JSON.parse(readFileSync(examplePath, "utf8")) as {
      source: { networkId: string };
    };
    json.source.networkId = "XDC";
    assert.throws(() => parseMessage(json), (error: unknown) => {
      assert.ok(error instanceof XimError);
      assert.equal(error.code, "INVALID_MESSAGE");
      return true;
    });
  });
});
