import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { bytesEqual, getBit, toHex } from "../src/bytes.js";
import { keccak256 } from "../src/hash.js";
import {
  SparseMerkleTree,
  emptyTreeRoot,
  proofFromJson,
  proofToJson,
  verifyCompactProof,
} from "../src/smt.js";

function digest(label: string): Uint8Array {
  return keccak256(new TextEncoder().encode(label));
}

describe("sparse Merkle tree", () => {
  it("reads key bits from the high bit of the first byte", () => {
    const key = new Uint8Array(32);
    key[0] = 0x80;
    key[31] = 0x01;
    assert.equal(getBit(key, 0), 1);
    assert.equal(getBit(key, 1), 0);
    assert.equal(getBit(key, 254), 0);
    assert.equal(getBit(key, 255), 1);
  });

  it("proves absence in an empty tree", () => {
    const tree = new SparseMerkleTree();
    assert.ok(bytesEqual(tree.root, emptyTreeRoot()));
    const proof = tree.prove(digest("missing"), "absent");
    assert.equal(verifyCompactProof(tree.root, proof), true);
    assert.equal(proof.valueHash, null);
  });

  it("proves a single leaf with an empty sibling list", () => {
    const tree = new SparseMerkleTree();
    const key = digest("only");
    const value = digest("state");
    tree.set(key, value);
    const proof = tree.prove(key, "present");
    assert.equal(proof.siblings.length, 0);
    assert.equal(verifyCompactProof(tree.root, proof), true);
    assert.deepEqual(proofFromJson(proofToJson(proof)).key, proof.key);
  });

  it("is independent of insertion order", () => {
    const forward = new SparseMerkleTree();
    const reverse = new SparseMerkleTree();
    const keys = [0, 1, 2, 3, 4].map((index) => digest(`key-${index}`));
    const values = [0, 1, 2, 3, 4].map((index) => digest(`value-${index}`));
    for (let index = 0; index < keys.length; index++) forward.set(keys[index]!, values[index]!);
    for (let index = keys.length - 1; index >= 0; index--) reverse.set(keys[index]!, values[index]!);
    assert.ok(bytesEqual(forward.root, reverse.root));

    for (let index = 0; index < keys.length; index++) {
      const proof = forward.prove(keys[index]!, "present");
      assert.equal(verifyCompactProof(forward.root, proof), true);
      assert.equal(verifyCompactProof(reverse.root, proof), true);
    }
  });

  it("rejects a tampered sibling and a stale proof after an update", () => {
    const tree = new SparseMerkleTree();
    const left = digest("left");
    const right = digest("right");
    tree.set(left, digest("l0"));
    tree.set(right, digest("r0"));
    const proof = tree.prove(left, "present");
    assert.equal(verifyCompactProof(tree.root, proof), true);

    const tampered = {
      ...proof,
      siblings: proof.siblings.map((sibling, index) => {
        if (index !== 0) return sibling;
        const copy = new Uint8Array(sibling);
        copy[0] ^= 0xff;
        return copy;
      }),
    };
    if (tampered.siblings.length > 0) {
      assert.equal(verifyCompactProof(tree.root, tampered), false);
    }

    tree.set(left, digest("l1"));
    assert.equal(verifyCompactProof(tree.root, proof), false);
    assert.equal(verifyCompactProof(tree.root, tree.prove(left, "present")), true);
    assert.notEqual(toHex(tree.get(left)!), toHex(digest("l0")));
  });

  it("returns to the empty root after every leaf is removed", () => {
    const tree = new SparseMerkleTree();
    const keys = [digest("a"), digest("b"), digest("c")];
    for (const key of keys) tree.set(key, digest(`value-${toHex(key)}`));
    for (const key of keys) tree.remove(key);
    assert.equal(tree.size, 0);
    assert.ok(bytesEqual(tree.root, emptyTreeRoot()));
    assert.equal(verifyCompactProof(tree.root, tree.prove(keys[0]!, "absent")), true);
  });
});
