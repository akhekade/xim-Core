import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { readFileSync } from "node:fs";
import path from "node:path";
import { describe, it } from "node:test";
import { runLifecycle } from "../src/demo.js";
import { parseMessage } from "../src/validate.js";

const root = path.join(import.meta.dirname, "..");
const examplePath = path.join(root, "examples", "usdc-eth-to-xdc.json");

describe("reference lifecycle", () => {
  it("settles the sample transfer and replays it", () => {
    const message = parseMessage(JSON.parse(readFileSync(examplePath, "utf8")) as unknown);
    const report = runLifecycle(message);
    assert.equal(report.steps.length, 7);
    assert.deepEqual(
      report.steps.map((step) => step.status),
      ["CREATED", "SOURCE_FINAL", "COMMITTED", "VERIFIED", "EXECUTING", "SETTLED", "ACKNOWLEDGED"],
    );
    assert.equal(report.inclusionVerified, true);
    assert.equal(report.absenceVerified, true);
    assert.equal(report.replayVerified, true);
    assert.equal(report.eventCount, 7);
    assert.equal(report.log.entries.length, 7);
  });

  it("prints a message id from the CLI", () => {
    const result = spawnSync(
      process.execPath,
      ["--import", "tsx", "src/cli.ts", "id", "examples/usdc-eth-to-xdc.json"],
      { cwd: root, encoding: "utf8" },
    );
    assert.equal(result.status, 0, result.stderr);
    assert.match(result.stdout, /^0x[0-9a-f]{64}\n$/);
  });
});
